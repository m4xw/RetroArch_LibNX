Example: 
Snes9x.png
Snes9x 2010.png
(exactly as on the menu!)
